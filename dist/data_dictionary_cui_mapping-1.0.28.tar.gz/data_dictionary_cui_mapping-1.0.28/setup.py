# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['data_dictionary_cui_mapping',
 'data_dictionary_cui_mapping.configs',
 'data_dictionary_cui_mapping.metamap',
 'data_dictionary_cui_mapping.metamap.skr_web_api',
 'data_dictionary_cui_mapping.metamap.utils',
 'data_dictionary_cui_mapping.umls',
 'data_dictionary_cui_mapping.umls.utils',
 'data_dictionary_cui_mapping.utils']

package_data = \
{'': ['*'], 'data_dictionary_cui_mapping.configs': ['apis/*', 'custom/*']}

install_requires = \
['hydra-core>=1.3.1,<2.0.0',
 'omegaconf>=2.3.0,<3.0.0',
 'openpyxl>=3.0.10',
 'pandas>=1.5.2',
 'prefect[viz]>=2.8.3,<3.0.0',
 'python-dotenv==0.21.1',
 'requests-html>=0.10.0,<0.11.0',
 'requests>=2.28.1',
 'wheel>=0.38.4,<0.39.0']

setup_kwargs = {
    'name': 'data-dictionary-cui-mapping',
    'version': '1.0.28',
    'description': '',
    'long_description': '',
    'author': 'Kevin Armengol',
    'author_email': 'kevin.armengol@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': '',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
